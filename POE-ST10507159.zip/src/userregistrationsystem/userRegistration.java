package userregistrationsystem;

import java.util.Scanner;

public class userRegistration 
{
     private static String userName;
    private static String password;
    private static String cellPhoneNumber;
    private static String firstName;
    private static String lastName;

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("=================Registration===============");
        
        // FIRST NAME//
        
        System.out.print("Please enter your first name: ");
        firstName = input.nextLine();

        while (firstName.isEmpty()) {
            System.out.println("First name cannot be empty");
            System.out.print("Please enter your first name: ");
            firstName = input.nextLine();
        }
        
        // LAST NAME //
        
        System.out.print("Please enter your last name: ");
        lastName = input.nextLine();

        while (lastName.isEmpty()) {
            System.out.println("Last name cannot be empty");
            System.out.print("Please enter your last name: ");
            lastName = input.nextLine();
        }

        Login login = new Login(firstName, lastName);
        
        // CHECK USERNAME//
        
        System.out.print("Enter your username (less than 5 characters and must contain an underscore): ");
        userName = input.nextLine();

        while (!login.checkUserName(userName)) {
            System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.");
            System.out.print("Enter your username (less than 5 characters and must contain an underscore): ");
            userName = input.nextLine();
        }
        
        // CHECK PASSWORD COMPLEXITY //
       
        System.out.print("Create a password (at least 8 characters, 1 capital letter, 1 number, 1 special character): ");
        password = input.nextLine();

        while (!login.checkPasswordComplexity(password)) {
            System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            System.out.print("Create a password (at least 8 characters, 1 capital letter, 1 number, 1 special character): ");
            password = input.nextLine();
        }
        
        // CHECK CELL PHONE NUMBER//
        
        System.out.print("Please enter cellphone number with international country code: ");
        cellPhoneNumber = input.nextLine();

        while (!login.checkCellPhoneNumber(cellPhoneNumber)) {
            System.out.println("Cell phone number incorrectly formatted or does not contain international code, please correct the number and try again");
            System.out.print("Please enter cellphone number with international country code: ");
            cellPhoneNumber = input.nextLine();
        }
        
        // REGISTRATION STATUS //
        
        String regStatus = login.registerUser(userName, password, cellPhoneNumber, firstName, lastName);
        System.out.println(regStatus);
        
        // LOGIN STATUS //
        
        if (regStatus.equals("Registration successful.")) {
            System.out.println("*Login*");

            boolean loggedIn = false;

            while (!loggedIn) {
                System.out.print("Enter the username you created: ");
                String loginUser = input.nextLine();

                System.out.print("Enter the password you created: ");
                String loginPass = input.nextLine();

                String loginStatus = login.returnLoginStatus(loginUser, loginPass);
                System.out.println(loginStatus);

                if (loginStatus.contains("Welcome")) {
                    loggedIn = true;
                } else {
                    System.out.println("Login failed, please try again");
                }
            }
           
            // PART 3: LOAD STORED MESSAGES FROM JSON ON STARTUP //
           
            StoredMessages.loadFromJSON();
            
            // QUICKCHAT MENU //            
            
            System.out.println("\nWelcome to QuickChat.");

            boolean running = true;
            int messageCounter = 0;
            SendMessage lastMessage = null;

            while (running) {
                System.out.println("\n1) Send Messages");
                System.out.println("2) Show recently sent messages");
                System.out.println("3) Quit");
                System.out.println("4) Stored Messages");
                System.out.print("Choose an option: ");
                
                String optionStr = input.nextLine();
                if(!optionStr.matches("\\d+"))
                {
                    System.out.println("Invalid input.");
                    continue;
                }
                int option = Integer.parseInt(optionStr);

                switch (option) {
                    case 1:
                        System.out.print("How many messages do you want to send? ");
                        int totalMessages = Integer.parseInt(input.nextLine());

                        for (int i = 0; i < totalMessages; i++) {
                            messageCounter++;

                            System.out.print("Enter recipient cell number (with international code): ");
                            String recipient = input.nextLine();

                            System.out.print("Enter message (max 250 characters): ");
                            String text = input.nextLine();

                            SendMessage msg = new SendMessage(messageCounter, recipient, text);
                            lastMessage = msg;

                            String lengthCheck = msg.checkMessageLength();
                            System.out.println(lengthCheck);

                            if (lengthCheck.startsWith("Message exceeds")) {
                                continue;
                            }

                            System.out.println(msg.checkRecipientCell());

                            System.out.println("\n1) Send Message");
                            System.out.println("2) Disregard Message");
                            System.out.println("3) Store Message to send later");
                            System.out.print("Choose: ");
                            int choice = Integer.parseInt(input.nextLine());

                            System.out.println(msg.SentMessages(choice));
                            System.out.println("\n" + msg.printMessages());
                        }

                        if (lastMessage != null) {
                            System.out.println("\nTotal messages: " + lastMessage.returnTotalMessages());
                        }
                        break;

                    case 2:
                        System.out.println("Coming Soon.");
                        break;

                    case 3:
                        System.out.println("Goodbye.");
                        running = false;
                        break;

                    case 4:
                        storedMessagesMenu(input);
                        break;
                    default:
                        System.out.println("Invalid option.");
                }
            }
        }

        input.close();
    }
    private static void storedMessagesMenu(Scanner input)
    {
        boolean inSubMenu = true;
        
        while (inSubMenu)
        {
            System.out.println("\n------ Stored Messages Menu --------");
            System.out.println("a. Display sender and recipient of all stored messages");
            System.out.println("b. Display the longest stored message");
            System.out.println("c. Search for a message ID and display recipient and message");
            System.out.println("d. Search for all messages stored for a particular recipient");
            System.out.println("e. Delete a message using the message hash");
            System.out.println("f. Display full report of all stored messages");
            System.out.println("0. Back to Main Menu");
            System.out.println("Choose an option: ");
            
            String choice = input.nextLine().toLowerCase();
            
            switch(choice)
            {
                case "a":
                    if (StoredMessages.storedMessages.isEmpty())
                    {
                        System.out.println("No stored messages.");
                        
                        for(SendMessage msg : StoredMessages.storedMessages)
                        {
                            System.out.println("Sender: Developer | Recipient: " + msg.getRecipient());
                        }
                        break;
                    }
                    
                case "b":
                     if (StoredMessages.storedMessages.isEmpty()) { System.out.println("No messages."); break; }
                    SendMessage longest = StoredMessages.storedMessages.get(0);
                    for (SendMessage msg : StoredMessages.storedMessages) {
                        if (msg.getText().length() > longest.getText().length()) {
                            longest = msg;
                        }
                    }
                    System.out.println("Longest Message: " + longest.getText());
                    break;
                    
                case "c":
                    System.out.print("Enter Message ID: ");
                    String searchId = input.nextLine();
                    boolean foundId = false;
                    for (SendMessage msg : StoredMessages.storedMessages) 
                    {
                        if (msg.getMessageID().equals(searchId)) 
                        {
                            System.out.println("Recipient: " + msg.getRecipient() + "\nMessage: " + msg.getMessageText());
                            foundId = true;
                            break;
                        }
                    }
                    if (!foundId)
                    {
                        System.out.println("Message ID not found.");
                        break;
                    }
                    
                case "d":
                    System.out.print("Enter Recipient Number: ");
                    String searchRec = input.nextLine();
                    boolean foundRec = false;
                    for (SendMessage msg : StoredMessages.storedMessages) {
                        if (msg.getRecipient().equals(searchRec)) {
                            System.out.println("ID: " + msg.getMessageID() + " | Message: " + msg.getText());
                            foundRec = true;
                        }
                    }
                    if (!foundRec) System.out.println("No messages found for this recipient.");
                    break;
                    
                case "e":
                    System.out.print("Enter Message Hash to delete: ");
                    String hashToDelete = input.nextLine();
                    boolean deleted = false;
                    for (int i = 0; i < StoredMessages.storedMessages.size(); i++) {
                        if (StoredMessages.storedMessages.get(i).getMessageHash().equals(hashToDelete)) {
                            String deletedText = StoredMessages.storedMessages.get(i).getText();
                            StoredMessages.storedMessages.remove(i);
                            StoredMessages.saveToJSON(); // Update JSON file
                            System.out.println("Message: \"" + deletedText + "\" successfully deleted.");
                            deleted = true;
                            break;
                        }
                    }
                    if (!deleted) System.out.println("Hash not found.");
                    break;
                    
                case "f":
                    System.out.println("\n--- FULL STORED MESSAGES REPORT ---");
                    for (SendMessage msg : StoredMessages.storedMessages) {
                        System.out.println("Message Hash: " + msg.getMessageHash());
                        System.out.println("Recipient: " + msg.getRecipient());
                        System.out.println("Message: " + msg.getText());
                        System.out.println("-----------------------------------");
                    }
                    break;
                    
                case "0":
                     inSubMenu = false;
                    break;
                    
                default:
                    System.out.println("Invalid option.");
            }
        }
    }

}