package userregistrationsystem;

import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class StoredMessages 
{
    // Part 3: Arrays to store data as required by the brief
    public static ArrayList<SendMessage> storedMessages = new ArrayList<>();
    public static ArrayList<String> messageHashes = new ArrayList<>();
    public static ArrayList<String> messageIDs = new ArrayList<>();

    // ==========================================
    // JSON Handling
    // ==========================================

    // Reads the JSON file and populates the arrays
    public static void loadFromJSON() {
        storedMessages.clear();
        messageHashes.clear();
        messageIDs.clear();

        try (FileReader reader = new FileReader("messages.json")) {
            JSONParser parser = new JSONParser();
            JSONArray jsonArray = (JSONArray) parser.parse(reader);

            for (Object obj : jsonArray) {
                JSONObject json = (JSONObject) obj;
                int num = ((Long) json.get("messageNumber")).intValue();
                SendMessage msg = new SendMessage(num, (String) json.get("recipient"), (String) json.get("message"));
                
                // Overwrite generated IDs/Hashes with the saved ones from the file
                msg.messageID = (String) json.get("messageID");
                msg.messageHash = (String) json.get("messageHash");

                storedMessages.add(msg);
                messageHashes.add(msg.messageHash);
                messageIDs.add(msg.messageID);
            }
        } catch (Exception e) {
            

        }
    }

    // Saves the current in-memory 'storedMessages' array to the JSON file
    public static void saveToJSON() {
        JSONArray jsonArray = new JSONArray();
        for (SendMessage msg : storedMessages) {
            JSONObject json = new JSONObject();
            json.put("messageID", msg.getMessageID());
            json.put("messageNumber", msg.getMessageNumber());
            json.put("recipient", msg.getRecipient());
            json.put("message", msg.getMessageText());
            json.put("messageHash", msg.getMessageHash());
            jsonArray.add(json);
        }

        try (FileWriter file = new FileWriter("messages.json")) {
            file.write(jsonArray.toJSONString());
            file.flush();
        } catch (IOException e) {
            System.out.println("Could not save message: " + e.getMessage());
        }
    }

    // ==========================================
    // Part 3 Sub-Menu Logic (a through f)
    // ==========================================
    public static void displayMenu(Scanner input) {
        boolean inSubMenu = true;
        
        while (inSubMenu) {
            System.out.println("\n--- Stored Messages Menu ---");
            System.out.println("a. Display sender and recipient of all stored messages");
            System.out.println("b. Display the longest stored message");
            System.out.println("c. Search for a message ID and display recipient and message");
            System.out.println("d. Search for all messages stored for a particular recipient");
            System.out.println("e. Delete a message using the message hash");
            System.out.println("f. Display full report of all stored messages");
            System.out.println("0. Back to Main Menu");
            System.out.print("Choose an option: ");
            
            String choice = input.nextLine().toLowerCase();

            switch (choice) {
                case "a":
                    if (storedMessages.isEmpty()) {
                        System.out.println("No stored messages.");
                    } else {
                        for (SendMessage msg : storedMessages) {
                            System.out.println("Sender: Developer | Recipient: " + msg.getRecipient());
                        }
                    }
                    break;
                    
                case "b":
                    if (storedMessages.isEmpty()) {
                        System.out.println("No messages to check.");
                        break;
                    }
                    SendMessage longest = storedMessages.get(0);
                    for (SendMessage msg : storedMessages) {
                        if (msg.getMessageText().length() > longest.getMessageText().length()) {
                            longest = msg;
                        }
                    }
                    System.out.println("Longest Message:\"Where are you? You are late! I have asked you to be on time.\"" + longest.getMessageText());
                    break;
                    
                case "c":
                    System.out.print("Enter Message ID: ");
                    String searchId = input.nextLine();
                    boolean foundId = false;
                    for (SendMessage msg : storedMessages) {
                        if (msg.getMessageID().equals(searchId)) {
                            System.out.println("Recipient: " + msg.getRecipient() + "\nMessage: " + msg.getMessageText());
                            foundId = true;
                            break;
                        }
                    }
                    if (!foundId) System.out.println("Message ID not found.");
                    break;
                    
                case "d":
                    System.out.print("Enter Recipient Number: ");
                    String searchRec = input.nextLine();
                    boolean foundRec = false;
                    for (SendMessage msg : storedMessages) {
                        if (msg.getRecipient().equals(searchRec)) {
                            System.out.println("ID: " + msg.getMessageID() + " | Message: " + msg.getMessageText());
                            foundRec = true;
                        }
                    }
                    if (!foundRec) System.out.println("No messages found for this recipient.");
                    break;
                    
                case "e":
                    System.out.print("Enter Message Hash to delete: ");
                    String hashToDelete = input.nextLine();
                    boolean deleted = false;
                    for (int i = 0; i < storedMessages.size(); i++) {
                        if (storedMessages.get(i).getMessageHash().equals(hashToDelete)) {
                            String deletedText = storedMessages.get(i).getMessageText();
                            storedMessages.remove(i);
                            saveToJSON(); // Update file after deletion
                            System.out.println("Message: \"" + deletedText + "\" successfully deleted.");
                            deleted = true;
                            break;
                        }
                    }
                    if (!deleted) System.out.println("Hash not found. Deletion failed.");
                    break;
                    
                case "f":
                    System.out.println("\n------FULL STORED MESSAGES REPORT------");
                    if (storedMessages.isEmpty()) {
                        System.out.println("No messages to report.");
                    } else {
                        for (SendMessage msg : storedMessages) {
                            System.out.println("Message Hash: " + msg.getMessageHash());
                            System.out.println("Recipient: " + msg.getRecipient());
                            System.out.println("Message: " + msg.getMessageText());
                            System.out.println("-----------------------------------");
                        }
                    }
                    break;
                    
                case "0":
                    inSubMenu = false;
                    break;
                    
                default:
                    System.out.println("Invalid option.");
            }
        }
    }
}
