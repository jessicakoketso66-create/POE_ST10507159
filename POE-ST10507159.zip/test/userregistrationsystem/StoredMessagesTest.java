package userregistrationsystem;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.*;

public class StoredMessagesTest 
{

    @BeforeEach
    public void setUp() {
        // Clear arrays to start fresh for each test
        SendMessage.sentMessages.clear();
        StoredMessages.storedMessages.clear();
        StoredMessages.messageHashes.clear();
        StoredMessages.messageIDs.clear();
        
        // Populate using the specific Test Data tables from the assignment
        SendMessage.sentMessages.add(new SendMessage(1, "+27834557896", "Did you get the cake?"));
        SendMessage.sentMessages.add(new SendMessage(4, "0838884567", "It is dinner time !"));
        
        StoredMessages.storedMessages.add(new SendMessage(2, "+27838884567", "Where are you? You are late! I have asked you to be on time."));
        StoredMessages.storedMessages.add(new SendMessage(5, "+27838884567", "Ok, I am leaving without you."));
    }

    @Test
    public void testSentMessagesArrayCorrectlyPopulated() {
        // Test Data: Developer entry for 1-4
        // Expected: “Did you get the cake?”, “It is dinner time !”
        assertEquals(2, SendMessage.sentMessages.size());
        assertEquals("Did you get the cake?", SendMessage.sentMessages.get(0).getText());
        assertEquals("It is dinner time !", SendMessage.sentMessages.get(1).getText());
    }

    @Test
    public void testDisplayLongestMessage() {
        // Test Data: message 1-4
        // Expected: “Where are you? You are late! I have asked you to be on time.”
        SendMessage longest = StoredMessages.storedMessages.get(0);
        for (SendMessage msg : StoredMessages.storedMessages) {
            if (msg.getText().length() > longest.getText().length()) {
                longest = msg;
            }
        }
        assertEquals("Where are you? You are late! I have asked you to be on time.", longest.getText());
    }
    
   
    @Test
    public void testSearchForMessageID() {
        // Test Data: message 4
        // Expected: recipient "0838884567", message "It is dinner time !"
        SendMessage msg4 = SendMessage.sentMessages.get(1); 
        assertEquals("0838884567", msg4.getRecipient());
        assertEquals("It is dinner time !", msg4.getText());
    }

    @Test
    public void testSearchAllMessagesForParticularRecipient() {
        // Test Data: +27838884567
        // Expected: 2 messages found
        String targetRecipient = "+27838884567";
        int count = 0;
        for (SendMessage msg : StoredMessages.storedMessages) {
            if (msg.getRecipient().equals(targetRecipient)) {
                count++;
            }
        }
        assertEquals(2, count);
    }

    @Test
    public void testDeleteMessageUsingHash() {
        // Test Data: Test Message 2 (Where are you?...)
        SendMessage msgToDelete = StoredMessages.storedMessages.get(0);
        String hashToDelete = msgToDelete.getMessageHash();
        
        // Simulate the deletion logic
        StoredMessages.storedMessages.removeIf(msg -> msg.getMessageHash().equals(hashToDelete));
        
        assertEquals(1, StoredMessages.storedMessages.size());
        assertEquals("Ok, I am leaving without you.", StoredMessages.storedMessages.get(0).getText());
    }

    @Test
    public void testDisplayReport() {
        // Verifies the report format includes Hash, Recipient, and Message
        SendMessage testMsg = StoredMessages.storedMessages.get(0);
        String report = testMsg.printMessages();
        
        assertTrue(report.contains("Message Hash: "));
        assertTrue(report.contains("Recipient: " + testMsg.getRecipient()));
        assertTrue(report.contains("Message: " + testMsg.getText()));
    }
}